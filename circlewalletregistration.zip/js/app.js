import { W3SSdk } from "@circle-fin/w3s-pw-web-sdk";

const appId = import.meta.env.VITE_CIRCLE_APP_ID;
const baseUrl = import.meta.env.BASE_URL;
const apiEndpoint = `${baseUrl}api/endpoints`;

const ui = {
  email: document.querySelector("#email"),
  networkSelect: document.querySelector("#networkSelect"),
  btnSendOtp: document.querySelector("#btnSendOtp"),
  btnVerifyOtp: document.querySelector("#btnVerifyOtp"),
  btnInitialize: document.querySelector("#btnInitialize"),
  btnCreateWallet: document.querySelector("#btnCreateWallet"),
  btnRefresh: document.querySelector("#btnRefresh"),
  btnReset: document.querySelector("#btnReset"),
  btnCopyAddress: document.querySelector("#btnCopyAddress"),
  sdkBadge: document.querySelector("#sdkBadge"),
  statusBox: document.querySelector("#statusBox"),
  deviceId: document.querySelector("#deviceId"),
  authState: document.querySelector("#authState"),
  targetNetwork: document.querySelector("#targetNetwork"),
  walletCard: document.querySelector("#walletCard"),
  walletId: document.querySelector("#walletId"),
  walletAddress: document.querySelector("#walletAddress"),
  walletBlockchain: document.querySelector("#walletBlockchain"),
  walletUsdc: document.querySelector("#walletUsdc"),
  debug: document.querySelector("#debug"),
};

const state = {
  sdk: null,
  sdkReady: false,
  deviceId: "",
  deviceToken: "",
  deviceEncryptionKey: "",
  otpToken: "",
  userToken: "",
  encryptionKey: "",
  challengeId: "",
  wallets: [],
  usdcBalance: null,
  email: "",
  selectedBlockchain: localStorage.getItem("circleTargetNetwork") || "ETH-SEPOLIA",
};


async function parseJsonResponse(response) {
  const text = await response.text();

  if (!text) {
    return {};
  }

  try {
    return JSON.parse(text);
  } catch {
    return {
      error: text,
    };
  }
}

function setStatus(message, type = "info") {
  ui.statusBox.textContent = message;
  ui.statusBox.className = `status status-${type}`;
}

function setSdkBadge(text, kind = "waiting") {
  ui.sdkBadge.textContent = text;
  ui.sdkBadge.className = `badge badge-${kind}`;
}

function apiErrorMessage(data, fallback) {
  if (!data) return fallback;
  if (typeof data === "string") return data;
  const message = data.message || data.error || data.data?.message;
  const code = data.code || data.data?.code;
  if (code && message) return `[${code}] ${message}`;
  return message || fallback;
}

function publicDebugState() {
  // Intentionally do not display userToken/encryptionKey/deviceEncryptionKey values.
  return {
    sdkReady: state.sdkReady,
    selectedBlockchain: state.selectedBlockchain,
    deviceId: state.deviceId,
    otpSessionReady: Boolean(
      state.deviceToken && state.deviceEncryptionKey && state.otpToken
    ),
    authenticated: Boolean(state.userToken && state.encryptionKey),
    challengeId: state.challengeId || null,
    wallets: state.wallets,
    usdcBalance: state.usdcBalance,
  };
}

function render() {
  if (ui.networkSelect) {
    ui.networkSelect.value = state.selectedBlockchain;
  }
  if (ui.targetNetwork) {
    ui.targetNetwork.textContent = state.selectedBlockchain;
  }

  ui.deviceId.textContent = state.deviceId || "–";
  ui.authState.textContent = state.userToken
    ? `Email verified${state.email ? `: ${state.email}` : ""}`
    : "Not signed in";

  const hasOtpSession =
    state.deviceToken && state.deviceEncryptionKey && state.otpToken;
  const authenticated = state.userToken && state.encryptionKey;
  const selectedWallet = state.wallets.find(
    (wallet) => wallet.blockchain === state.selectedBlockchain
  );
  const hasWallet = Boolean(selectedWallet);

  ui.btnSendOtp.disabled =
    !state.sdkReady || !state.deviceId || !ui.email.value.trim();

  ui.btnVerifyOtp.disabled =
    !state.sdkReady || !hasOtpSession || Boolean(authenticated);

  ui.btnInitialize.disabled =
    !authenticated || Boolean(state.challengeId) || hasWallet;

  ui.btnCreateWallet.disabled =
    !authenticated || !state.challengeId || hasWallet;

  ui.btnRefresh.disabled = !authenticated;

  if (hasWallet) {
    const wallet = selectedWallet;
    ui.walletCard.classList.remove("hidden");
    ui.walletId.textContent = wallet.id || "–";
    ui.walletAddress.textContent = wallet.address || "–";
    ui.walletBlockchain.textContent = wallet.blockchain || "–";
    ui.walletUsdc.textContent =
      state.usdcBalance === null ? "–" : state.usdcBalance;
  } else {
    ui.walletCard.classList.add("hidden");
  }

  ui.debug.textContent = JSON.stringify(publicDebugState(), null, 2);
}

async function callApi(action, params = {}) {
  const response = await fetch(apiEndpoint, {
    method: "POST",
    credentials: "same-origin",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action, ...params }),
  });

  const data = await parseJsonResponse(response);

  if (!response.ok) {
    const err = new Error(apiErrorMessage(data, `HTTP ${response.status}`));
    err.status = response.status;
    err.data = data;

    throw err;
  }

  return data;
}

async function initializeSdk() {
  if (state.sdkReady && state.sdk) {
    return;
  }

  if (!appId || appId === "YOUR_CIRCLE_APP_ID") {
    setSdkBadge("Configuration missing", "error");
    setStatus(
      "VITE_CIRCLE_APP_ID is missing. Add the Circle App ID to .env.local or Vercel and deploy again.",
      "error"
    );
    return;
  }

  try {
    const onLoginComplete = async (error, result) => {
      if (error || !result) {
        console.error("Circle Email OTP login failed:", error);
        setStatus(
          error?.message || "Email authentication failed.",
          "error"
        );
        state.userToken = "";
        state.encryptionKey = "";
        render();
        return;
      }

      state.userToken = result.userToken;
      state.encryptionKey = result.encryptionKey;

      try {
        state.sdk.setAuthentication({
          userToken: state.userToken,
          encryptionKey: state.encryptionKey,
        });
      } catch (authError) {
        console.warn("Circle SDK authentication setup warning:", authError);
      }

      setStatus(
        "Email verified. Loading your existing Circle wallet…",
        "success"
      );
      render();

      await loadWallets("login");
    };

    state.sdk = new W3SSdk(
      {
        appSettings: { appId },
      },
      onLoginComplete
    );

    state.sdkReady = true;
    setSdkBadge("SDK ready", "ok");
    setStatus(`Circle SDK is ready. Target network: ${state.selectedBlockchain}. Enter an email address and send the OTP.`);

    const cached = localStorage.getItem("circleDeviceId");
    if (cached) {
      state.deviceId = cached;
    } else {
      state.deviceId = await state.sdk.getDeviceId();
      localStorage.setItem("circleDeviceId", state.deviceId);
    }

    render();
  } catch (error) {
    console.error(error);
    setSdkBadge("SDK error", "error");
    setStatus(
      `Circle SDK could not be initialized: ${error?.message || error}`,
      "error"
    );
    render();
  }
}

async function requestOtp() {
  const email = ui.email.value.trim();

  if (!email || !state.deviceId) return;
  state.email = email;

  try {
    // Start a new Circle login session.
    state.deviceToken = "";
    state.deviceEncryptionKey = "";
    state.otpToken = "";
    state.userToken = "";
    state.encryptionKey = "";
    state.challengeId = "";
    state.wallets = [];
    state.usdcBalance = null;
    render();

    setStatus("Requesting OTP from Circle…");

    const data = await callApi("requestEmailOtp", {
      deviceId: state.deviceId,
      email,
    });

    state.deviceToken = data.deviceToken;
    state.deviceEncryptionKey = data.deviceEncryptionKey;
    state.otpToken = data.otpToken;

    state.sdk.updateConfigs({
      appSettings: { appId },
      loginConfigs: {
        deviceToken: data.deviceToken,
        deviceEncryptionKey: data.deviceEncryptionKey,
        otpToken: data.otpToken,
        email: { email },
      },
    });

    setStatus(
      "OTP has been sent. Open the email and then click “Verify OTP”.",
      "success"
    );
    render();
  } catch (error) {
    console.error(error);
    setStatus(`OTP could not be sent: ${error.message}`, "error");
    render();
  }
}

function verifyOtp() {
  if (!state.sdk) return;

  try {
    setStatus("Opening the Circle OTP window…");
    state.sdk.verifyOtp();
  } catch (error) {
    console.error(error);
    setStatus(`The OTP window could not be opened: ${error.message}`, "error");
  }
}

async function initializeUser() {
  if (!state.userToken) return;

  const blockchain = state.selectedBlockchain;

  try {
    setStatus(`Preparing ${blockchain} wallet…`);

    const data = await callApi("initializeUser", {
      userToken: state.userToken,
      blockchain,
    });

    state.challengeId = data.challengeId;

    if (!state.challengeId) {
      throw new Error("Circle did not return a challengeId.");
    }

    setStatus(
      `${blockchain} wallet challenge is ready. Click “Create Wallet”.`,
      "success"
    );
    render();
  } catch (error) {
    const circleCode = Number(error?.data?.code ?? error?.data?.data?.code);

    if (circleCode === 155106) {
      try {
        const data = await callApi("createWallet", {
          userToken: state.userToken,
          blockchain,
        });

        state.challengeId = data.challengeId;

        if (!state.challengeId) {
          throw new Error("Circle did not return a challengeId.");
        }

        setStatus(
          `${blockchain} additional-wallet challenge is ready. Click “Create Wallet”.`,
          "success"
        );
        render();
        return;
      } catch (createError) {
        console.error(createError);
        setStatus(`Wallet preparation failed: ${createError.message}`, "error");
        render();
        return;
      }
    }

    console.error(error);
    setStatus(`Initialization failed: ${error.message}`, "error");
    render();
  }
}

function createWallet() {
  if (!state.sdk || !state.challengeId) return;

  try {
    state.sdk.setAuthentication({
      userToken: state.userToken,
      encryptionKey: state.encryptionKey,
    });

    setStatus("Executing wallet challenge…");

    state.sdk.execute(state.challengeId, (error) => {
      if (error) {
        console.error("Challenge failed:", error);
        setStatus(
          `Wallet could not be created: ${error?.message || "Unknown error"}`,
          "error"
        );
        return;
      }

      setStatus("Challenge completed. Loading wallet data…");

      window.setTimeout(async () => {
        state.challengeId = "";
        await loadWallets("afterCreate");
      }, 2000);
    });
  } catch (error) {
    console.error(error);
    setStatus(`Challenge could not be started: ${error.message}`, "error");
  }
}

async function loadWallets(source = "refresh") {
  if (!state.userToken) return;

  try {
    setStatus("Loading wallet data…");

    const data = await callApi("listWallets", {
      userToken: state.userToken,
    });

    state.wallets = Array.isArray(data.wallets) ? data.wallets : [];

    if (!state.wallets.length) {
      state.usdcBalance = null;
      setStatus(
        `Email verified, but no Circle wallets exist yet. Click “Prepare Wallet” to create a ${state.selectedBlockchain} wallet.`,
        "info"
      );
      render();
      return;
    }

    const primaryWallet = state.wallets.find(
      (wallet) => wallet.blockchain === state.selectedBlockchain
    );

    if (!primaryWallet) {
      state.usdcBalance = null;
      setStatus(
        `No ${state.selectedBlockchain} wallet exists yet. Click “Prepare Wallet” to create one.`,
        "info"
      );
      render();
      return;
    }

    await loadUsdcBalance(primaryWallet.id);

    if (source === "afterCreate") {
      setStatus("SCA wallet was created successfully.", "success");
    } else if (source === "alreadyInitialized" || source === "login") {
      setStatus(`${state.selectedBlockchain} wallet loaded successfully.`, "success");
    } else {
      setStatus("Wallet data refreshed successfully.", "success");
    }

    render();
  } catch (error) {
    console.error(error);
    setStatus(`Wallet data could not be loaded: ${error.message}`, "error");
    render();
  }
}

async function loadUsdcBalance(walletId) {
  try {
    const data = await callApi("getTokenBalance", {
      userToken: state.userToken,
      walletId,
    });

    const balances = Array.isArray(data.tokenBalances)
      ? data.tokenBalances
      : [];

    const usdc = balances.find((entry) => {
      const symbol = entry?.token?.symbol || "";
      const name = entry?.token?.name || "";
      return symbol.startsWith("USDC") || name.includes("USDC");
    });

    state.usdcBalance = usdc?.amount ?? "0";
  } catch (error) {
    console.warn("USDC balance could not be loaded:", error);
    state.usdcBalance = "not available";
  }
}

function resetTest() {
  state.deviceToken = "";
  state.deviceEncryptionKey = "";
  state.otpToken = "";
  state.userToken = "";
  state.encryptionKey = "";
  state.challengeId = "";
  state.wallets = [];
  state.usdcBalance = null;
  state.email = "";
  ui.email.value = "";
  setStatus("Signed out locally. Enter an email address to sign in again.");
  render();
}

async function copyAddress() {
  const address = state.wallets.find(
    (wallet) => wallet.blockchain === state.selectedBlockchain
  )?.address;
  if (!address) return;

  try {
    await navigator.clipboard.writeText(address);
    const old = ui.btnCopyAddress.textContent;
    ui.btnCopyAddress.textContent = "Copied";
    window.setTimeout(() => {
      ui.btnCopyAddress.textContent = old;
    }, 1300);
  } catch {
    setStatus("Wallet address could not be copied to the clipboard.", "error");
  }
}

async function startApplication() {
  render();
  await initializeSdk();
}

ui.networkSelect.addEventListener("change", async () => {
  state.selectedBlockchain = ui.networkSelect.value;
  localStorage.setItem("circleTargetNetwork", state.selectedBlockchain);
  state.challengeId = "";
  state.usdcBalance = null;

  if (state.userToken) {
    await loadWallets("networkChange");
  } else {
    setStatus(
      `Target network changed to ${state.selectedBlockchain}. Sign in with Circle OTP.`,
      "info"
    );
    render();
  }
});

ui.email.addEventListener("input", render);
ui.btnSendOtp.addEventListener("click", requestOtp);
ui.btnVerifyOtp.addEventListener("click", verifyOtp);
ui.btnInitialize.addEventListener("click", initializeUser);
ui.btnCreateWallet.addEventListener("click", createWallet);
ui.btnRefresh.addEventListener("click", () => loadWallets("refresh"));
ui.btnReset.addEventListener("click", resetTest);
ui.btnCopyAddress.addEventListener("click", copyAddress);

startApplication();
